# Http async post library
Library for http async post request
## History

#### Version 0.1
Initial version
- Arduino library with example sketch
- Post only

## Credits
Based on ideas from
- [ESPAsyncWebServer](https://github.com/me-no-dev/ESPAsyncWebServer.git)

## Required
[ESPAsyncWebServer](https://github.com/me-no-dev/ESPAsyncWebServer.git)

### AsyncHttpPost
